<template>
  <div class="xz-header">
    塔罗占卜
  </div>
</template>

<script>
export default {
  data () {
    return {
      msg: 'Welcome to Your Vue.js App'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style  lang="scss"  scoped>
.xz-header{
    text-align: center;
    height: 84px;
    line-height: 84px;
    font-size: 34px;
    color: #fff;
    background: #3B1A62;
}
</style>
